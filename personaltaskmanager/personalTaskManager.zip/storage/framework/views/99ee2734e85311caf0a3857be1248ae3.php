<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Add Task</title>

    <style>
        body {
            font-family: Arial;
            background: #f4f6f8;
            padding: 40px;
        }

        .container {
            max-width: 600px;
            margin: auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
        }

        input,
        textarea,
        select {
            width: 100%;
            padding: 10px;
            margin: 8px 0 20px;
            box-sizing: border-box;
        }

        button,
        a {
            padding: 10px 16px;
            background: #222;
            color: white;
            text-decoration: none;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .error {
            color: red;
        }
    </style>
</head>

<body>

<div class="container">

    <h1>Add New Task</h1>

    <?php if($errors->any()): ?>
        <div class="error">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('tasks.store')); ?>" method="POST">

        <?php echo csrf_field(); ?>

        <label>Task Name</label>

        <input
            type="text"
            name="task_name"
            value="<?php echo e(old('task_name')); ?>"
            required
        >

        <label>Description</label>

        <textarea
            name="description"
            rows="5"
        ><?php echo e(old('description')); ?></textarea>

        <label>Status</label>

        <select name="status">

            <option value="Pending">
                Pending
            </option>

            <option value="Completed">
                Completed
            </option>

        </select>

        <label>Due Date</label>

        <input
            type="date"
            name="due_date"
            value="<?php echo e(old('due_date')); ?>"
        >

        <button type="submit">
            Add Task
        </button>

        <a href="<?php echo e(route('tasks.index')); ?>">
            Cancel
        </a>

    </form>

</div>

</body>
</html><?php /**PATH /workspaces/PersonalTaskManager/personaltaskmanager/resources/views/tasks/create.blade.php ENDPATH**/ ?>